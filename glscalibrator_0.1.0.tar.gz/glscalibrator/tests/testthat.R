library(testthat)
library(glscalibrator)

test_check("glscalibrator")
